package com.biarj.food_ordering_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Registration : AppCompatActivity() {

    lateinit var etRegistrationName: EditText
    lateinit var etRegistrationEmail :EditText
    lateinit var etRegistrationNumber : EditText
    lateinit var etRegistrationAddress : EditText
    lateinit var etRegistrationPassword : EditText
    lateinit var etRegistrationConfirmPassword : EditText
    lateinit var btnRegister : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        etRegistrationName = findViewById(R.id.etRegistrationName)
        etRegistrationEmail = findViewById(R.id.etRegistrationEmail)
        etRegistrationNumber = findViewById(R.id.etRegistrationNumber)
        etRegistrationAddress = findViewById(R.id.etRegistrationAddress)
        etRegistrationPassword = findViewById(R.id.etRegistrationPassword)
        etRegistrationConfirmPassword = findViewById(R.id.etRegistrationConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)

        btnRegister.setOnClickListener{

            var intent = Intent(this@Registration, Blank2Activity::class.java)

            intent.putExtra("Name", etRegistrationName.text.toString())
            intent.putExtra("Email", etRegistrationEmail.text.toString())
            intent.putExtra("Number", etRegistrationNumber.text.toString())
            intent.putExtra("Address", etRegistrationAddress.text.toString())
            intent.putExtra("Password", etRegistrationPassword.text.toString())
            intent.putExtra("ConfirmPassword", etRegistrationConfirmPassword.text.toString())

            startActivity(intent)


        }
    }
}
