package com.biarj.food_ordering_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Blank3Activity : AppCompatActivity() {

    lateinit var txtforgotnumber : TextView
    lateinit var txtforgotemail : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blank3)

        txtforgotnumber = findViewById(R.id.txtforgotnumber)
        txtforgotemail = findViewById(R.id.txtforgotemail)

        txtforgotnumber.text = intent.getStringExtra("number")
        txtforgotemail.text = intent.getStringExtra("email")

    }

}
