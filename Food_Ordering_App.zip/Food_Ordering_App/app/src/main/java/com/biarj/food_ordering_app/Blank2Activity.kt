package com.biarj.food_ordering_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Blank2Activity : AppCompatActivity() {

    lateinit var txtRDisplayName : TextView
    lateinit var txtRDisplayAddress : TextView
    lateinit var txtRDisplayNumber : TextView
    lateinit var txtRDisplayEmail : TextView
    lateinit var txtRDisplayPassword : TextView
    lateinit var txtRDisplayConfirmPassword : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blank2)

        txtRDisplayName = findViewById(R.id.txtRDisplayName)
        txtRDisplayEmail = findViewById(R.id.txtRDisplayEmail)
        txtRDisplayNumber = findViewById(R.id.txtRDisplayNumber)
        txtRDisplayAddress = findViewById(R.id.txtRDisplayAddress)
        txtRDisplayPassword = findViewById(R.id.txtRDisplayPassword)
        txtRDisplayConfirmPassword = findViewById(R.id.txtRDisplayConfirmPassword)

        txtRDisplayName.text = intent.getStringExtra("Name")
        txtRDisplayEmail.text = intent.getStringExtra("Email")
        txtRDisplayAddress.text = intent.getStringExtra("Address")
        txtRDisplayNumber.text = intent.getStringExtra("Number")
        txtRDisplayPassword.text = intent.getStringExtra("Password")
        txtRDisplayConfirmPassword.text = intent.getStringExtra("ConfirmPassword")

    }
}
