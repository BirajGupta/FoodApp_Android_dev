package com.biarj.food_ordering_app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import org.w3c.dom.Text

class BlankActivity : AppCompatActivity() {

    lateinit var txtDisplayNumber : TextView
    lateinit var txtDisplayPassword : TextView
    lateinit var txtBlank1LogOut : TextView
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blank)
        println("create")

        sharedPreferences = getSharedPreferences(getString(R.string.preferences_file_name),Context.MODE_PRIVATE)

        val number = intent.getStringExtra("Number")
        val password = intent.getStringExtra("Password")


        txtBlank1LogOut = findViewById(R.id.txtBlank1LogOut)
        txtDisplayNumber = findViewById(R.id.txtDisplayNumber)
        txtDisplayPassword = findViewById(R.id.txtDisplayPassword)

        println(number)
        println(password)


        if(number != null  && password != null) {
            txtDisplayNumber.text = number
            txtDisplayPassword.text = password

            sharedPreferences.edit().putString("Number",number).apply()
            sharedPreferences.edit().putString("Password",password).apply()
        }else{
            txtDisplayNumber.text = sharedPreferences.getString("Number","def num")
            txtDisplayPassword.text = sharedPreferences.getString("Password","def pass")
        }



        txtBlank1LogOut.setOnClickListener{

            val intent = Intent(this@BlankActivity,LoginActivity::class.java)

            sharedPreferences.edit().putBoolean("isLoggedIn",false).apply()

            startActivity(intent)
            finish()

        }


    }

    override fun onStop() {
        super.onStop()
        println("stop")

    }

    override fun onResume() {
        super.onResume()
        println("resume")

    }

    override fun onRestart() {
        super.onRestart()
        println("restart")


    }
}
