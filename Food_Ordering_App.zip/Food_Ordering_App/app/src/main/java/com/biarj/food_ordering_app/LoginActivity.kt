package com.biarj.food_ordering_app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var btnlogin: Button
    lateinit var etMobileNumber : EditText
    lateinit var etPassword: EditText
    lateinit var txtForgotPassword: TextView
    lateinit var txtSignUp: TextView
    lateinit var sharedPreferences : SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences = getSharedPreferences(getString(R.string.preferences_file_name),Context.MODE_PRIVATE)

        setContentView(R.layout.activity_login)

        btnlogin = findViewById(R.id.btnLogin)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtSignUp = findViewById(R.id.txtSignUp)
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)


        btnlogin.setOnClickListener{

            val mobilenumber = etMobileNumber.text.toString()
            val password = etPassword.text.toString()

            if(password != "" && mobilenumber != "") {

                val intent = Intent(this@LoginActivity, BlankActivity::class.java)
                intent.putExtra("Number",mobilenumber)
                intent.putExtra("Password",password)
                startActivity(intent)
                finish()

                savePreferences()

            }else{
                Toast.makeText(this@LoginActivity, "Enter credentials", Toast.LENGTH_SHORT).show()

            }
        }

        txtForgotPassword.setOnClickListener{

            val intent = Intent(this@LoginActivity, ForgotPassword::class.java)
            startActivity(intent)

        }

        txtSignUp.setOnClickListener{

           val intent = Intent(this@LoginActivity,Registration::class.java)

            startActivity(intent)
        }
    }


    fun savePreferences(){
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
    }


}
